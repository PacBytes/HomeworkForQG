#ifndef LINK_STARK_H
#define LINK_STARK_H
#include <iostream>
#include <functional>

// 通用链栈节点
template<typename T>
struct Node {
    T data;
    Node<T>* next;
};

// 链栈类
template<typename T>
class LinkStack {
private:
    Node<T>* top; // 栈顶，采用指针更好处理 NULL
    size_t size;
public:
    LinkStack():
        top(nullptr), // 初始化 top 为 nullptr
        size(0) // 初始化长度
    {}
    ~LinkStack(); // 析构
    // getter
    size_t getSize() const;
    // 为空检测
    bool isEmpty() const;
    // 入栈
    void push(const T&data); // 用引用更安全
    // 出栈
    T pop();
    // 获得栈顶数据（不会弹出）
    T getTopData() const;
    void traverse(std::function<void(T&)>);
    void traverse(std::function<void(T&, T&)>, T&);
};

#endif