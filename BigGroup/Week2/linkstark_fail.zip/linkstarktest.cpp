#include <iostream>
#include <functional>
#include "linkstark.h"
#include <cassert>

// 元素为空检测
template<typename T>
bool LinkStack<T>::isEmpty() const {
    return size == 0;
}

// 析构
template<typename T>
LinkStack<T>::~LinkStack(){
    while (!isEmpty()) {
        pop();
    }
}

// 获取元素个数
template<typename T>
size_t LinkStack<T>::getSize() const {
    return size;
}

// 入栈
template<typename T>
void LinkStack<T>::push(const T&data){
    Node<T>* newNode = new Node<T>; // 申请节点空间
    newNode->data = data; // 赋值
    newNode->next = top; // 设置 next
    top = newNode; // 重置 top
    ++size;
}


// 出栈
template<typename T>
T LinkStack<T>::pop() {
    // 空栈检测
    if (isEmpty()) {
        std::cout << "栈里没有元素，没有元素出栈" << std::endl;
        return T(); // 返回默认构造的值
    }
    // 存储栈顶节点数据
    T data = top->data;
    // 删除栈顶节点并重置栈顶
    Node<T>* x = top;
    top = top->next;
    delete x;

    --size;
    // 返回栈顶节点数据
    return data;
}

// 获取栈顶数据
template<typename T>
T LinkStack<T>::getTopData() const {
    // 空栈检测
    if (isEmpty()) {
        std::cout << "栈里没有元素！！！" << std::endl;
        return T(); // 返回默认构造的值
    }
    return top->data;
}

void printData(int& data) {
    std::cout << data << std::endl;
}

void sumUp(int& element, int& sum){
    sum += element;
}

int main() {
    // 创建一个整型链栈
    LinkStack<int> stack;

    // 测试空栈检测
    assert(stack.isEmpty());
    std::cout << "空栈检测通过" << std::endl;

    // 测试获取元素个数
    assert(stack.getSize() == 0);
    std::cout << "获取元素个数测试通过" << std::endl;

    // 入栈操作
    stack.push(10);
    stack.push(20);
    stack.push(30);

    // 测试获取栈顶元素
    assert(stack.getTopData() == 30);
    std::cout << "获取栈顶元素测试通过" << std::endl;

    // 测试栈的大小
    assert(stack.getSize() == 3);
    std::cout << "获取栈的大小测试通过" << std::endl;

    // 出栈操作
    int poppedElement = stack.pop();
    assert(poppedElement == 30);
    std::cout << "出栈操作测试通过" << std::endl;

    // 再次获取栈顶元素并打印
    assert(stack.getTopData() == 20);
    std::cout << "再次获取栈顶元素测试通过" << std::endl;

    // 再次测试栈的大小
    assert(stack.getSize() == 2);
    std::cout << "再次获取栈的大小测试通过" << std::endl;

    // 测试traverse
    stack.traverse(printData);

    int sum = 0;
    stack.traverse(sumUp, sum);
    // 预期结果为 
    //assert(sum == 105);

    // 清空栈
    while (!stack.isEmpty()) {
        stack.pop();
    }

    // 再次测试空栈检测
    assert(stack.isEmpty());
    std::cout << "再次测试空栈检测通过" << std::endl;

    // 再次测试获取栈的大小
    assert(stack.getSize() == 0);
    std::cout << "再次获取栈的大小测试通过" << std::endl;

    std::cout << ">_\n所有断言测试通过！" << std::endl;

    return 0;
}
